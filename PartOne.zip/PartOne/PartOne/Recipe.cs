﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartOne
{
    internal class Recipe
    {
        //Declarations
        private string[] ingredients;
        private string[] steps;
        private double[] originalQuantities; 

       //constructor
        public Recipe(int numIngredients, int numSteps)
        {
            ingredients = new string[numIngredients];
            originalQuantities = new double[numIngredients];
            steps = new string[numSteps];
        }
        //Methodss
        public void AddIngredient(int index, string name, double quantity, string unit)
        {
            ingredients[index] = $"{quantity} {unit} of {name}";
            originalQuantities[index] = quantity; // Store original quantity
        }

        public void AddStep(int index, string description)
        {
            steps[index] = description;
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");
            foreach (string ingredient in ingredients)
            {
                Console.WriteLine(ingredient);
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < ingredients.Length; i++)
            {
                double originalQuantity = originalQuantities[i];
                double scaledQuantity = Math.Round(originalQuantity * factor, 2);
                ingredients[i] = $"{scaledQuantity} {ingredients[i].Split(' ')[1]} of {ingredients[i].Split(' ')[3]}";
            }
        }

        public void ResetQuantities()
        {
            for (int i = 0; i < ingredients.Length; i++)
            {
                ingredients[i] = $"{originalQuantities[i]} {ingredients[i].Split(' ')[1]} of {ingredients[i].Split(' ')[3]}";
            }
        }

        public void ClearRecipe()
        {
            Array.Clear(ingredients, 0, ingredients.Length);
            Array.Clear(steps, 0, steps.Length);
        }

    }
}