﻿using PartOne;

public class Program
{
    private static void Main(string[] args)
    {

        Console.WriteLine("Welcome !");

        Recipe recipe = null;
        bool exit = false;

        //
        while (!exit)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Enter your recipe");
            Console.WriteLine("2. Display the  recipe:");
            Console.WriteLine("3. Scale recipe");
            Console.WriteLine("4. Return recipe to original");
            Console.WriteLine("5. Clear entered data");
            Console.WriteLine("6. Exit");
            Console.Write("Enter your choice ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter the number of ingredients: ");
                    int numIngredients = int.Parse(Console.ReadLine());

                    Console.Write("Enter the number of steps: ");
                    int numSteps = int.Parse(Console.ReadLine());

                    recipe = new Recipe(numIngredients, numSteps);

                    for (int i = 0; i < numIngredients; i++)
                    {
                        Console.WriteLine($"Enter the Ingredient {i + 1}:");
                        Console.Write("Enter the Name: ");
                        string name = Console.ReadLine();

                        Console.Write("Enter the Quantity: ");
                        double quantity = double.Parse(Console.ReadLine());

                        Console.Write("Enter the Unit of measurement: ");
                        string unit = Console.ReadLine();

                        recipe.AddIngredient(i, name, quantity, unit);
                    }

                    for (int i = 0; i < numSteps; i++)
                    {
                        Console.WriteLine($"Enter the Step {i + 1}:");
                        Console.Write("Enter the Description: ");
                        string description = Console.ReadLine();

                        recipe.AddStep(i, description);
                    }
                    break;

                case 2:
                    if (recipe != null)
                        recipe.DisplayRecipe();
                    else
                        Console.WriteLine(" Enter a recipe first.");
                    break;

                case 3:
                    if (recipe != null)
                    {
                        Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
                        double factor = Convert.ToDouble(Console.ReadLine());
                        recipe.ScaleRecipe(factor);
                    }
                    else
                        Console.WriteLine("Enter a recipe first.");
                    break;

                case 4:
                    if (recipe != null)
                        recipe.ResetQuantities();
                    else
                        Console.WriteLine("Enter a recipe first.");
                    break;

                case 5:
                    recipe = null;
                    Console.WriteLine("Data cleared. Enter a new recipe.");
                    break;

                case 6:
                    exit = true;
                    Console.WriteLine("Thank you for using the app, Goodbye.");
                    break;

                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;

            }
        }
    }
}


    
   
   
